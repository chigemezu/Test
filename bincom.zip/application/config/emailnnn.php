<?php  
$config = Array(
  'protocol' => 'smtp',
  'smtp_host' => 'smtp.mailtrap.io',
  'smtp_port' => 2525,
  'smtp_user' => '791528458996b3',
  'smtp_pass' => '18f542d8b938b2',
  'crlf' => "\r\n",
  'newline' => "\r\n",
  'mailtype' => 'html',
  'smtp_crypto' => 'ssl',
);

?>