<!-- Newsletter -->
<section class=" p-5">
  <div class="container">
    <div class="row">
      <div class="d-md-flex justify-content-center align-items-center">
        <div class="col-lg-5">
          <h4>Add Result</h4>
          <?php if($this->session->flashdata('error')): ?>
            <div class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></div>
          <?php elseif($this->session->flashdata('msg')): ?>
            <div class="alert alert-success"><?php echo $this->session->flashdata('msg'); ?></div>
          <?php endif; ?>

          <?php echo form_open(); ?>
            <div class="row my-3">
             
              <div class="col-lg-12">
                <div class="form-group">
                  <label>Select Polling unit</label>
                  <select name="polling_unit" class="form-control">
                    <option>Select LGA</option>
                    <?php foreach ($pollingunit as $unit):?>
                      <option value="<?=$unit->uniqueid?>"><?=$unit->polling_unit_name?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
            </div>

            <div class="row my-3">
              <div class="col-lg-12">
                <div class="form-group">
                  <select name="partyid" class="form-control">
                    <option>Select Party</option>
                    <?php foreach ($party as $part):?>
                      <option value="<?=$part->partyid?>"><?=$part->partyname?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="form-group">
                  <label>Party Score</label>
                  <input type="number" name="party_score" placeholder="Party Score" class="form-control">
                </div>
              </div>
            </div>

            <div class="row my-3">
              <div class="col-lg-12">
                <div class="form-group">
                  <label>Enter your Name</label>
                  <input type="text" name="enter_by_name" placeholder="Enter name" class="form-control">
                </div>
              </div>
              <div class="col-lg-12 mt-3">
                <div class="form-group">
                  <button type="submit" name="submit" value="submit" class="btn btn-primary btn-block">Confirm</button>
                </div>
              </div>
            </div>
          
        </div>

      </div>
    </div>
  </div>
</section>

