



<!-- Newsletter -->
<section class=" p-5">
  <div class="container">
    <div class="row">
      <div class="d-md-flex justify-content-center align-items-center">
        <div class="col-lg-7">
          <table class="table">
            <thead>
              <tr>
                <th>RESULT OF THE <?=strtoupper($result->polling_unit_name)?> POLLING UNIT</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>POLLING UNIT NAME</td>
                <td><?=$result->polling_unit_name?></td>
              </tr>
               <tr>
                <td>POLLING UNIT NUMBER</td>
                <td><?=$result->polling_unit_number?></td>
              </tr>
               <tr>
                <td>UNIQUE WARD ID</td>
                <td><?=$result->uniquewardid?></td>
              </tr>
               <tr>
                <td>POLLING UNIT DESCRIPTION</td>
                <td><?=$result->polling_unit_description?></td>
              </tr>
               <tr>
                <td>LGA</td>
                <td><?=$result->lga_name?></td>
              </tr>
               <tr>
                <td>STATE NAME</td>
                <td><?=$result->state_name?></td>
              </tr>
               <tr>
                <td>Ward</td>
                <td><?=$result->ward_name?></td>
              </tr>
              <tr>
                <td><b>RESULT OFF ALL THE PARTIES IN <?=$result->polling_unit_name?> POLLING UNIT</b></td>
              </tr>
              <?php $total = 0; ?>
              <?php foreach($pollingresult as $poll): ?>
                <?php $total = $total+$poll->party_score; ?>
                <tr>
                  <td><?=$poll->party_abbreviation?></td>
                  <td><?=$poll->party_score?></td>
                </tr>
              <?php endforeach; ?>
              <tr>
                <td><b>Total Result</b></td>
                <td><b><?=number_format($total)?></b></td>
              </tr>
              
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>
</section>

