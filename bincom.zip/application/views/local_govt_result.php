<!-- Newsletter -->
<section class=" p-5">
  <div class="container">
    <div class="row">
      <div class="d-md-flex justify-content-center align-items-center">
        <div class="col-lg-7">
          <h4>Select the local government you wish to see the result</h4>
          <?php echo form_open(); ?>
            <div class="row my-3">
              <div class="col-lg-6">
                <div class="form-group">
                  <label>Please select LGA </label>
                  <select name="lga" class="form-control">
                    <option>Select LGA</option>
                    <?php foreach ($all_lga as $lga):?>
                      <option value="<?=$lga->uniqueid?>"><?=$lga->lga_name?></option>

                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="col-lg-6 py-4">
                <div class="form-group">
                  <button type="submit" name="submit" value="submit" class="btn btn-primary">Confirm</button>
                </div>
              </div>
            </div>
          <?php echo form_close(); ?>
          <table class="table">
            <thead>
              <tr>
                <th>RESULT OF THE <?=strtoupper($result->polling_unit_name)?> POLLING UNIT</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
             
              <tr >
                <td ><b>POLLING UNIT</b></td>
                <td><b>PARTY NAME</b></td>
                <td><b>PARTY SCORE</b></td>

              </tr>
              <?php $total = 0; ?>
              <?php if(!empty($results)>0): ?>
                <h4><?=$lga_name?></h4>
                <?php foreach($results as $result): ?>
                  <?php $total = $total+$result->party_score; ?>
                  <tr>
                    <td><?=$result->polling_unit_name?></td>
                    <td><?=$result->party_abbreviation?></td>
                    <td><?=$result->party_score?></td>
                  </tr>
                <?php endforeach; ?>
                <tr>
                  <td><b>Total Result</b></td>
                  <td><b><?=number_format($total)?></b></td>
                </tr>
              <?php else: ?>
                <tr>
                  <td colspan="2">The LGA selected does not have a result record in the database</td>
                </tr>
              <?php endif; ?>
              
              
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>
</section>

