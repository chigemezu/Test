<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Bincom</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

 

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?=base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?=base_url('assets/css/style.css')?>" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
        <div class="container"> 
          <span> 
            <a href="#index" class="navbar-brand" height="77">Bincom</a>
         </span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
            <span class="navbar-toggler-icon"></span>   
       </button>
               
        <div class="collapse navbar-collapse" id="navmenu">
          <ul class="navbar-nav ms-auto border-*-0"> 
           <li class="nav-item">
             <a href="<?=base_url('home')?>" class="nav-link nav-item active">HOME</a>
           </li>
           <li class="nav-item">
             <a href="<?=base_url('local_govt_result')?>" class="nav-link nav-item active">Local govt Result</a>
           </li>
           <li class="nav-item">
             <a href="<?=base_url('add_result')?>" class="nav-link nav-item active">Add Result</a>
           </li>
            
          
         </ul>
        </div>
       </div>
    </nav>    
