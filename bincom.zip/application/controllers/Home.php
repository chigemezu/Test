<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct(){
		parent::__construct();
		
	}


	public function index()
	{
		$this->home();
	}
	
	public function home(){
		$head = $data = array();
		$head['title'] = ("Home");
		$head['description'] = ("Home");
		$head['keywords'] = "";

        $id ="8";

		$this->db->from('polling_unit as poll');
        $this->db->join('lga as lga', 'poll.lga_id=lga.uniqueid');
        $this->db->join('states as state', 'lga.state_id=state.state_id');
        $this->db->join('ward as ward', 'poll.ward_id=ward.uniqueid');
        $this->db->where('poll.uniqueid', $id);
        $query1 = $this->db->get();
        $data['result'] = $query1->row();

       $data['pollingresult'] = $this->db->get_where('announced_pu_results',array('polling_unit_uniqueid'=>$id))->result();


        


		$this->load->view('layout/reg-login-header',$head);
		$this->load->view('home',$data);
		 $this->load->view('layout/reg-login-footer');	
	}
	public function localGovtResult(){
		$head = $data = array();
		$head['title'] = ("local government result search");
		$head['description'] = ("local government result search");

		$data['all_lga'] = $this->db->get('lga')->result();

		if($this->input->post('submit')=="submit"){
			$lga_id = $this->input->post('lga');
				$lganame = $this->db->get_where('lga',array('uniqueid'=>$lga_id))->row();
				$checklga = $this->db->get_where('polling_unit',array('lga_id'=>$lga_id))->result();
				foreach($checklga as $check){
					$uniqueid = $check->uniqueid;

					$this->db->from('announced_pu_results as result');
			        $this->db->join('polling_unit as poll', 'poll.uniqueid=result.polling_unit_uniqueid');
			       
			        $this->db->where('result.polling_unit_uniqueid', $uniqueid);
			        $query1 = $this->db->get();
			        $data['results'] = $query1->result();
			        $data['lga_name'] = $lganame->lga_name;
				}
		}

		$this->load->view('layout/reg-login-header',$head);
		$this->load->view('local_govt_result',$data);
		$this->load->view('layout/reg-login-footer');	
	}
	
	public function result(){
		$head = $data = array();
		$head['title'] = ("Result");
		$head['description'] = ("Result");
		$data['pollingunit'] = $this->db->get('polling_unit')->result();
		$data['party'] = $this->db->get('party')->result();
		
			
		if($this->input->post('submit')=="submit"){
			$polling_unit = $this->input->post('polling_unit');
			$party_score = $this->input->post('party_score');
			$party = $this->input->post('partyid');
			$enter_by_name = $this->input->post('enter_by_name');

			$reg_data = array(
				'polling_unit_uniqueid' => $polling_unit,
				'party_abbreviation' => $party,
				'party_score' => $party_score,
				'entered_by_user' => $enter_by_name
			);

				$this->db->insert('announced_pu_results', $ref_data);
				$this->session->set_flashdata('msg',' Result successfully Added');
				redirect(base_url('add_result'));

		}

			

		$this->load->view('layout/reg-login-header',$head);
		$this->load->view('add_result',$data);
		$this->load->view('layout/reg-login-footer');	
	}
	
	



	


}
